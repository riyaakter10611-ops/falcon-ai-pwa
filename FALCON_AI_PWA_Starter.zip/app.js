const $=id=>document.getElementById(id);
let candles=[];
const fmt=n=>Number.isFinite(n)?n.toFixed(5):"—";
function ema(values,period){const k=2/(period+1);let out=[];let prev=values[0];for(let i=0;i<values.length;i++){prev=i===0?values[i]:values[i]*k+prev*(1-k);out.push(prev)}return out}
function rsi(values,period=14){let out=Array(values.length).fill(null);if(values.length<=period)return out;let gains=0,losses=0;for(let i=1;i<=period;i++){let d=values[i]-values[i-1];gains+=Math.max(d,0);losses+=Math.max(-d,0)}let ag=gains/period,al=losses/period;out[period]=al===0?100:100-100/(1+ag/al);for(let i=period+1;i<values.length;i++){let d=values[i]-values[i-1];ag=(ag*(period-1)+Math.max(d,0))/period;al=(al*(period-1)+Math.max(-d,0))/period;out[i]=al===0?100:100-100/(1+ag/al)}return out}
function macd(values){const a=ema(values,12),b=ema(values,26),m=values.map((_,i)=>a[i]-b[i]),s=ema(m,9);return {m,s}}
function render(){
 if(!candles.length)return;
 const c=candles.map(x=>x.close),e20=ema(c,20),e50=ema(c,50),rv=rsi(c),mc=macd(c),i=c.length-1;
 $("lastPrice").textContent=fmt(c[i]);$("ema20").textContent=fmt(e20[i]);$("ema50").textContent=fmt(e50[i]);$("rsi").textContent=rv[i]===null?"Need 15+ candles":rv[i].toFixed(1);$("macd").textContent=fmt(mc.m[i]);$("count").textContent=c.length;
 let bull=0,bear=0;
 if(c[i]>e20[i])bull++;else bear++;
 if(e20[i]>e50[i])bull++;else bear++;
 if(mc.m[i]>mc.s[i])bull++;else bear++;
 if(rv[i]!==null){if(rv[i]>50&&rv[i]<70)bull++;if(rv[i]<50&&rv[i]>30)bear++}
 let signal=bull>=3?"BULLISH BIAS":bear>=3?"BEARISH BIAS":"NEUTRAL / WAIT";
 let card=$("signalCard");card.className="signal "+(bull>=3?"bull":bear>=3?"bear":"neutral");$("signal").textContent=signal;
 $("signalNote").textContent=`Bullish checks: ${bull} • Bearish checks: ${bear}. Educational indicator summary only.`;
 $("rows").innerHTML=candles.slice(-8).map((x,j)=>{let k=candles.length-Math.min(8,candles.length)+j;return `<tr><td>${escapeHtml(x.time||"—")}</td><td>${fmt(c[k])}</td><td>${fmt(e20[k])}</td><td>${rv[k]===null?"—":rv[k].toFixed(1)}</td></tr>`}).reverse().join("");
 $("dataStatus").textContent=`${candles.length} candles loaded`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]))}
function parseCSV(text){
 const lines=text.trim().split(/\r?\n/);if(lines.length<3)throw Error("CSV-তে অন্তত ২টি candle row দরকার");
 const headers=lines[0].split(",").map(x=>x.trim().toLowerCase().replace(/["']/g,""));
 const idx=(...names)=>headers.findIndex(h=>names.includes(h));
 const ci=idx("close","adj close","adj_close"),oi=idx("open"),hi=idx("high"),li=idx("low"),ti=idx("date","datetime","time","timestamp");
 if([ci,oi,hi,li].some(x=>x<0))throw Error("CSV header-এ Date, Open, High, Low, Close কলাম থাকতে হবে");
 return lines.slice(1).map(line=>{const p=line.split(",").map(x=>x.trim().replace(/^"|"$/g,""));return {time:ti>=0?p[ti]:"",open:+p[oi],high:+p[hi],low:+p[li],close:+p[ci]}}).filter(x=>[x.open,x.high,x.low,x.close].every(Number.isFinite));
}
$("csvFile").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{candles=parseCSV(await f.text());render();}catch(err){$("dataStatus").textContent=err.message}});
$("demoBtn").addEventListener("click",()=>{let p=1.10;candles=Array.from({length:80},(_,i)=>{p+=Math.sin(i*.7)*.0007+(i%9===0?-.0005:.0002);return {time:`Demo ${i+1}`,open:p-.0002,high:p+.0004,low:p-.0004,close:p}});$("timeframe").value="1m";render();$("dataStatus").textContent="Demo data only — not live prices"});
$("timeframe").addEventListener("change",()=>{$("candleHint").textContent=`Selected ${$("timeframe").value}. Ensure your imported CSV candles use this same timeframe. No live prices are fetched.`});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));