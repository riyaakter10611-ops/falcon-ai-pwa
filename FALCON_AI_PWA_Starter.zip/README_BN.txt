FALCON AI PWA — ANDROID INSTALL GUIDE

এই ZIP-এ একটি installable PWA starter app আছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এই ভার্সনে live market API নেই।
- 1m signal পেতে 1-minute candle-সহ CSV import করতে হবে।
- Demo data শুধু UI পরীক্ষা করার জন্য; এটি বাস্তব বাজারের তথ্য নয়।
- BULLISH/BEARISH BIAS নিশ্চিত BUY/SELL নির্দেশ নয়। Real-money trading নয়; paper/demo analysis-এর জন্য।

ফোন থেকে প্রকাশ/ইনস্টল:
1) ZIP extract করুন।
2) সব ফাইল একসঙ্গে একটি GitHub repository-তে upload করুন।
3) Repository Settings → Pages → Deploy from a branch → main → /(root) → Save।
4) GitHub Pages একটি https://...github.io/... ঠিকানা দেবে।
5) Android Chrome-এ URL খুলুন → ⋮ menu → Install app অথবা Add to Home screen।
6) FALCON AI আইকন ফোনের home screen-এ আসবে।

CSV format:
Date,Open,High,Low,Close
2026-11-15 10:00,1.1000,1.1010,1.0990,1.1005

Header-এ Date/Open/High/Low/Close থাকা জরুরি। 1m timeframe নির্বাচন করলে 1-minute candle data-ই দিন।
